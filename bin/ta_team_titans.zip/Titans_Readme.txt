+++ Do Not Repack this file for any reason +++

<8/7/01>
================================================================
Model Name:		 "TITANS for Quake3 TEAM ARENA"
Mesh, animations
Authors:		 Mike and Bill Jukes / aka Brothers Grim
Web address:             www.mindlessgrafx.com 
Email Address:		 mike3d@mindlessgrafx.com   

Skin Author:             Jason "Dark Horizon" Sallenbach
Email address:           dark_horizon_hl@hotmail.com  *  kingofyutan@hotmail.com
Web address:             http://www.polycount.com/cottages/darkhorizon 
Skins                    All Red male and female team skins and heads 

Skin Author:             F-X "OgroFix" Delmotte 
Email address:           Ogro@planetquake.com
Skins                    Blue male team skins and heads

Skin Author:             Ryan "ScoobyDoo" Jackson
Email address:           vegas_ryan@yahoo.com
Skins                    Blue Female team skins and heads

Male sounds:             Mike and Bill Jukes / Brothers Grim

Female taunt:            Denise "Angel_i" Sanders 
Email address:           angel_i@timesert.com   

Concept art:             Brothers Grim & bobotheseal bobotheseal@hotmail.com                  

Model description        "TITANS clan for Team Arena"


Special Thanks to:       Paul Jaquays of id software for getting the code changed 
                         to allow for new teams in Quake 3 Team Arena.
                         Also to all the programers at id for taking the time off
                         special projects to work on the team code, we thank you
                         and appreciate your hard work. 
                         To all the skinners on this project you all have done such
                         a fantastic job! we enjoyed working with you again and
                         look forward you working with you in the future. 


Other info:             This is meant to be a sort of template of sorts to help guide
                        the community in creating new clans for Team Arena.
                        A manual written by Paul Jaquays is available at:
Html format:            ftp://ftp.idsoftware.com/idstuff/quake3/misc/html_q3ta_teams.zip
RTF format:             ftp://ftp.idsoftware.com/idstuff/quake3/misc/rtf_q3ta_teams.zip
                         

================================================================


* How to use this model *
<INSTALLATION INFO>
Place pk3 file in your quake3 mission pack folder.


* Copyright / Permissions *
QUAKE(R) and QUAKE III Arena(R) are registered trademarks of id Software, Inc.


These model may be freely distributed UNALTERED.  Which means, you can't pull the readme
file out, or add your own stuff to it and pass it along as your own!
+++ Do Not Repack this file for any reason +++