CVE-2006-2082: directory traversal / information leak in Quake III Arena auto download feature

Ludwig Nussel and Thilo Shulz discovered a vulnerability letting a malicious client download files from a server if auto download is enabled ( sv_allowDownload 1 ).

Issue #2 ( CVE pending ): R_RemapShaders buffer overflow

A second issue fixed in this release would let a malicious server exploit a buffer overflow to execute a shellcode on connecting clients.

--
Updated binaries for the following games are available:

Quake III Arena - fixed at version 1.32c
Return To Castle Wolfenstein - fixed at version 1.41b
Wolfenstein: Enemy Territory - fixed at version 2.60b

If you run a server with any older version, please upgrade or consider turning off autodownload ( set sv_allowDownload to 0 ). Wolfenstein: Enemy Territory servers http/ftp download feature is not affected by CVE-2006-2082. If you don't wish to upgrade, you can decide to only enable http/ftp downloads and disable legacy downloads in that particular case.

Finally, server administrators should note that game servers should be running in restricted environments as much as possible ( unpriviledged accounts and chroot jails ). It's a good thing to do the same for clients, or at least ensure that you are properly firewalled.

