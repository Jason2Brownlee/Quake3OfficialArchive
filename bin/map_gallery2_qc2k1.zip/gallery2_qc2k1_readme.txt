================================================================
Title                   : gallery2_qc2k1.bsp
                          gallery2
Author                  : Paul Jaquays      
                                  
Email Address           : qc01model@idsoftware.com

Description             : Quake3 map displaying the contest entries in the 
           QuakeCon 2001 Map Object Model contest.
         
Notes: 			: This map does not contain md3 models. They will be 
           released separately.

Additional Credits to   : The modelers, who must remain unknown at this time. Timothee "Ttimo" Besset who helped me through dealings with GTKRadiant and then, with some of the final process of finishing out the map. Camilla "milla" Bennett who adapted Mark Adams's QuakeCon 2001 logo into the logo plaque used in the map. Kevin Blaker of Discreet and Jim Black of NVidia for wholeheartedly supporting this contest again. 


================================================================

* Play Information *

Single Player           : No bot support
Multiplayer             : It�s there � but don�t expect it to be great.

New Shaders             : Yeah � a bunch

* Construction *

Base                    : The gallery map from QuakeCon 2000
                          
Editors used            : Q3Radient, GTKRadient
 
Build time              : 3 days
Known Bugs              : Ignore them.
			   
			  


==============================================================================
  
* Copyright / Permissions *

The map is copyright 2000 - 2001 Id Software Inc. The models are copyright 2001 to their original creators. This map is not for redistribution outside of the contest judges. 

You may NOT edit this map and re-release it as your own work.  


*******************************************************************************
01 ODIUM
*******************************************************************************
Authors:                 Mesh, Mike and Bill Jukes
Web address:             www.mindlessgrafx.com  
Email 		         mike3d@mindlessgrafx.com   
Phone                    775 829-1026

Skin author              "Dark Horizon"  Jason Sallenbach
Email                    dark_horizon_hl@hotmail.com

info:                    This is a stone gargoyle, who�s eyes will
                         slowly turn on as bats fly out of the mouth.    

================================================================
*Information *
Total file size 195kb
polycount       711

* Copyright / Permissions *
The character Odium is an original creation by Mike and Bill Jukes copyright 2001.


*******************************************************************************
02 ARC-NEMESIS
*******************************************************************************
Author: 	Daniel "smeg" Vogt
Email:		thevogts@writeme.com 

Construction time:	About 2 weeks.
Construction tools:	Photoshop 5.5
			MAX 3
			Q3ASE (great program)
			Npherno's Tools
			Pop'N'Fresh's exporter
			Notepad (gotta love)

PK3 name:	        md3_arc_nemesis.pk3

-- Plug --

	First things first, I'd like to take this opportunity to mention that I am seeking employment as an artist, and would love for you to drop me a line!  (I am currently based in Australia but am considering relocation). I am dead serious about entering the games industry, and would love any opportunity to do so.

-- Notes --

	Yes, for some reason, the alpha blending on the cape causes a few visual glitches in places (the shoulders and where it draws behind the electricity mostly).  Also there appears to be problems with the handle of the axe.  For some reason it does not light properly, and always appears nearly black.  I believe it can be fixed with careful lighting...

	The skull at the top of the axe is the skull mapobject from quake3 (I couldn't model a good looking one myself).  The texture however, is new.

NOTE: This model looks bizarre if viewed with vertex lighting rather than lightmap.

-- Thanks --

	Thanks to everyone over on #model_design!  Without them, this model would still have existed...  but they made the endless bouts with NPherno's tools much more tolerable.  

Special thanks go to: Shainiel, Cassar (also the remainder of Half-Brick) Ari, Janus, MTE, Sec, R3koil and everyone else who's names I've forgotten.


*******************************************************************************
03 Punishment
*******************************************************************************
Author: 	Daniel "smeg" Vogt
Email:		thevogts@writeme.com 

Construction time:	Somewhere between 1 and 2 weeks.
Construction tools:	Photoshop 5.5
			MAX 3
			Q3ASE (great program)
			Npherno's Tools
			Pop'N'Fresh's exporter
			Notepad (gotta love)

PK3 name:	md3_punishment.pk3

-- Plug --

	First things first, I'd like to take this opportunity to mention that I am seeking employment as an artist, and would love for you to drop me a line!  (I am currently based in Australia but am considering relocation). I am dead serious about entering the games industry, and would love any opportunity to do so.

-- Notes --

	This model essentially uses every shader trick I could muster.  It probably also needs all the rendering power your card can muster, with the shader coming in at a whopping 7 stages.  :) 

	Obviously, the lava texture in this model was derived from a standard quake3 texture.  And for this reason, this model looks best when placed in a pool of that lava.

NOTE: This model looks particularly bizarre if viewed with vertex lighting rather than lightmap.

-- Thanks --

	Thanks to everyone over on #model_design!  Without them, this model would still have existed...  but they made the endless bouts with NPherno's tools much more tolerable.  

Special thanks go to: Shainiel, Cassar (also the remainder of Half-Brick) Ari, Janus, MTE, Sec, R3koil and everyone else who's names I've forgotten.


*******************************************************************************
04 MrSkull
*******************************************************************************
The QuakeCon 2001 Map Object Model Contest 
Description : map object for Qcon Contest
Name : MrSkull
Pak name : mrskull.pk3
Model name : mrskull.md3
Author : Michael "Veda" McInerney
Email: mike@cybercowboys.com

*******************************************************************************
05 Fountainhead
*******************************************************************************
573 polies
1 512x512 tga and various shader images

by Lucas �doc rob� Hardi
docrob@polycount.com

Any mappers interested in a reskinned version to better fit the style of their map, or some map textures in the style of this skin, please contact me.


*******************************************************************************
11 The Engine
*******************************************************************************
Quake3 Arena Mapmodel by Boris 'Karloff' Munser

author info:
----------------
name:		Boris Munser
e-mail: 	karl.off@berlin.de
homepage:	http://user.berlin.de/~karl.off

model info:
----------------
model filepath:	models/mapobjects/kfengine/kfengine.md3
model size: 	width 760, length 980, height 281.
vertices:	964
triangles:	1608

construction:
----------------
mesh:		milkshape3d
textures:	photoshop5.5
uvw-wrap:	lithunwrap/milkshape3d
shader-editing:	notepad++/editpad
model-viewer:	quake3:arena 1.29f
sound:		goldwave
prefab:		GtkRadiant 1.1
packaging:	WinZip
editing music:	The Prodigy: Breathe (well in the end, actually;)

texture info:
----------------
uncompressed images size: originally about 2 Megabytes of TGAs, partly converted to JPGs.
additional jpg's included as editorimages for radiant.

prefab info:
----------------
the prefab included in 'models/mabobjects/kfengine/prefab' subfolder contains model reference, clipping, 
and weaponclip-func_bobbing's that are synchronized with the model's deformvertexes movement. 
(do not carelessly walk into moving machinery ;]
!--> On edit/load prefab the spawnflags of the bobbers are forked in some cases, 
I have no clue yet what is happening: until that, check x-axis for the 'pushbox'-bobbers 
and uncheck every checkbox at the 'rotator'-bobbers after import - that will do it.
--> note that the two 'pushbox' bobbers have a noise key set to 
the custom sound in the sound subfolder of kfengine model.

******************
important note:
----------------
do NOT change the ANGLE of model in radiant! 
The movement of the machineryvertexes will not adjust to the new angle and look wrong.
On reasonable demand, angled versions of the model can be provided by the author ;)
******************

--------------------------------------------
(: this model is vertex-lighting friendly :)
--------------------------------------------

//karloff, 07/26/01


*******************************************************************************
12 Dragon_gate
*******************************************************************************

Hi, here is my model for the QuakeCon 2001 model contest.

a.) dragon_gate.md3 - is a gateway with a huge dragon head

Hope you like my work. So, thx and hf on the quakeCon01.

LowDragon

///////////////////////////////////////////////

Info about me (the artist :)

name 		: Juergen Timm (aka LowDragon)
e - mail 	: LowDragon@gmx.net

Info about the model	: >>

a.) dragon_gate.md3 	: 1 md3, 2 skins with 256x256

Tools, for the model 	: Nendo 1.1.6 and MilkShape 3D 1.5.7
     , for the skins 	: PaintShopPro 6.0/4.0
     , shader 		: no shader(s) for this model

Build time 		: 3 days

This model is property of juergen Timm (aka LowDragon). I build all parts of it 
by my self (model, skinmap and skin) for q3a and the QuakeCon 2001 model contest.

/////////////////////////////////////////////////

*******************************************************************************
13 Rope Bridge
*******************************************************************************
---------------------------------------------------------------------------
 MD3-CASE_BRIDGE.PK3, map object model

 Created for the QuakeCon 2001 Map Object Model Contest

 Created by Jeffrey R Chaplin (a.k.a. 'CASE') August 03, 2001
 ---------------------------------------------------------------------------

 Title:
 
   Rope Bridge

 Description:

   CASE_BRIDGE is an old wooden rope bridge that could possibly be found in 
   an abandoned gold mine shaft.  

 Usage:

   CASE_BRIDGE components can be joined together to form various bridge
   designs.  See case_bridge.map for an example.

   Component 1, case_bridge_flat, is the flat part of the bridge.  If only
   case_bridge_flat components were used the bridge would be completely flat.

   Components 2 and 3, case_bridge_step_left and case_bridge_step_right, are
   the steps of the bridge.  These step components are used to give the 
   bridge a curve or sag.  Use these components on both sides of component 1,
   case_bridge_flat.

   Note: case_bridge_step_left and case_bridge_step_right are mirrored 
         components; case_bridge_step_left is used left of a component,
         case_bridge_step_right is used right of a component (in top view).

   Component 4, case_bridge_connector, is a connection point to the bridge.  
   Use this component to connect things such as rope that will support the 
   bridge.

   Components 5, 6 and 7, case_bridge_broken_rope, case_bridge_broken_board and
   case_bridge_broken_board_top, are broken sections of the bridge.  These 
   components are used to give the bridge an old and broken down look.  Use 
   case_bridge_broken_rope for sections of the bridge where the board is no 
   longer attached.  Use case_bridge_broken_board and/or case_bridge_broken_board_top
   for sections where the board is still attached to the bridge, but dangling.

   Note: case_bridge_broken_board and case_bridge_broken_board_top are mirrored 
         components; case_bridge_broken_board has the rope on the bottom,
         case_bridge_broken_board_top has the rope on the top (in top view).

   Component 8, case_bridge_rope.jpg, is not a map object model, but a 
   texture to be used with component 4, case_bridge_connector.  A brush with
   this texture applied can be used to create a rope that supports the 
   bridge.

 Example:

   See case_bridge.map (map created with GtkRadiant 1.1-TA).

   Tested using case_bridge.map and the following bots:  Crash, Doom, Hunter.

 E-mail:


   If any part of this map object model is used in a custom map, please e-mail 
   the following to jeffrey@channel1.com:

     1.  Name of the custom map.
     2.  URL-link to the custom map.
     3.  Any comments.


*******************************************************************************
14 Zeus
*******************************************************************************
Modelname: zeus.md3
Creator: Dallas Nutsch
danutsch@home.com

*******************************************************************************
15 Train of Pain
*******************************************************************************
TRAIN OF PAIN

Andrew Deegear

blazeq@visto.com

*******************************************************************************
21 Griffin
*******************************************************************************
Tim Douthit
dead_gibs@yahoo.com

Two models:
Griffin.md3	Statue of a griffin 
Fountain.md3	Fountain with two Griffins

*******************************************************************************
22 Pharao
*******************************************************************************
                           ______
__________________________/Pharao\_________________________
A map object model for Quake ]|[ Arena

This model is intended as an entry for the 
"Quakecon 2001 Map Object Model Contest"
_______________
Technical data:\___________________________________________
Polycount:           1124 triangles
Texture bitmaps:     3 textures, each at 256x256 
                     pixels, jpg-format
Shaders:             none

___________________
Author Information:\_______________________________________
Nickname:	           Thomas �GIJoe� Pecht
Mail Adress:		   GIJoe@counter-strike.de
______
Notes:\_____________________________________________________
This model was successfully tested to be compatible with 
Quake 3 Arena and the Team Arena Add-on and the corresponding 
editors Q3Radiant 2.02 and GTKRadiant 1.1 TA


*******************************************************************************
23 Evil Egg
*******************************************************************************
Author: 	Daniel "smeg" Vogt
Email:		thevogts@writeme.com 

Construction time:	About 1 weeks.
Construction tools:	Photoshop 5.5
			MAX 3
			Q3ASE (great program)
			Npherno's Tools
			Pop'N'Fresh's exporter
			Notepad (gotta love)

PK3 name:	md3_evil_egg.pk3

-- Plug --

	First things first, I'd like to take this opportunity to mention that I am seeking employment as an artist, and would love for you to drop me a line!  (I am currently based in Australia but am considering relocation). I am dead serious about entering the games industry, and would love any opportunity to do so.

-- Notes --

	This model looks bizarre if viewed with vertex lighting rather than lightmap.

-- Thanks --

	Thanks to everyone over on #model_design!  Without them, this model would still have existed...  but they made the endless bouts with NPherno's tools much more tolerable.  

Special thanks go to: Shainiel, Cassar (also the remainder of Half-Brick) Ari, Janus, MTE, Sec, R3koil and everyone else who's names I've forgotten.


*******************************************************************************
24 Rhuilaanh Guard
*******************************************************************************
 ---------------------------------------------------------------------------
 MD3-CASE_RUILAANH.PK3, map object model

 Created for the QuakeCon 2001 Map Object Model Contest

 Created by Jeffrey R Chaplin (a.k.a. 'CASE') August 03, 2001
 ---------------------------------------------------------------------------

 Title:

   Ruilaanh Guard

 Description:
 
   This statue of the ruilaanh was created to honor the loyal 
   guard of the enemy, which are typically found at one if not all 
   entrances to the grounds.  It is not uncommon for a statue such 
   as this to be forged then bonded by the highest wizard to aid in 
   the confusion between the statue and an actual ruilaanh guard.

   The ruilaanh are very strong and agile creatures used 
   by the enemy as guards.  When standing tall they measure 11 
   feet with a wing span of 19 feet unfurled.  Though not used in 
   full flight, the wings assist in a leap of 21 yards and help 
   strike fear into prey when extended.  A sharpened-bone tail is
   used to pierce the side of prey when caught with razor sharp 
   claws, on both hand and feet, that are known to make halves of 
   stone.

   Ruilaanh, under the enemy's rule, travel in pairs and will not 
   attack unless otherwise ordered, making ruilaanh under their own 
   will, though lone travelers, much fiercer foes.

   To fell a ruilaanh, it is best to strike under the chin, through
   the throat and up into the skull.  Unfortunately, if you are in 
   the position to do so it is most likely because you, the prey, 
   have been caught, so make hast.

   Prey will make sound before a ruilaanh; they will not be heard
   until it is too late.
 
   The horns of a ruilaanh, when separated from the hosts body, are 
   rumored to bring the bearer good fortune in travels.

 E-mail:

   If any part of this map object model is used in a custom map, please e-mail 
   the following to jeffrey@channel1.com:

     1.  Name of the custom map.
     2.  URL-link to the custom map.
     3.  Any comments.


*******************************************************************************
25 Hand
*******************************************************************************
Model Name:			Hand  
Authors:			Tim tpe Evison		  	
Email Address:           	timevison@hotmail.com				
www tpe:			http://users.cybercity.dk/~dsl11905/resume/resume.html

Model Description:

David's hand reaching out to God's with a difference. About 1k poly This model is not finished, unfortunatly other commitments have prevented me from completing the map object. Nor has this model been in any way tested in game or level design tool (Its just luck if it works). It has been entered anyway in case someone would like to use it in their map, if so they are welcome to ask me to modify or complete it as they think necessary. The tga fspark was derived from an image contained in the id Software, Inc pk3 file and is included here to comply with the �Knock Our Socks Off� QuakeCon 2001 Map Object Model Contest.

Many thanks to those at polycount for all their help, especially Demon, and on the forums at quake3world, you have all been invaluable, I am sorry i havn't been ble to complete it on time for you. Most of all thanks to my wife Caro, for putting up with me dooing this instead of all the other more important things i should have been dooing with her.

================================================================
*
Software used: 3DS Max, Character Studio, Lightwave, 3d Explorer, Adobe Photoshop,  

* Copyright / Permissions *
QUAKE III Arena(R) are registered trademarks of id Software, Inc. This model may be freely distributed UNALTERED. It may be used as a base for other models only if full credit is given for to the original authors


*******************************************************************************
26 DragonMaw
*******************************************************************************
http://www.maelstromdev.dynip.com/skizot
http://homepages.ihug.com.au/~janus

================================================================
Accessory's Name	   
map-dragon.pk3
Dragon Maw
A bone skull of a deseaced dragon.
================================================================
Installation directory : /Quake III Arena/baseq3/

Model Author Info:
Legal Name : Chris �Janus� Snopek
ICQ : 38287620


Skin Author Info:
Legal Name :Scott �skizot� Deason
ICQ : 3549853

Janus's Email Address: janus@planetquake.com
SkizoT's Email Address: skizot@softhome.net

A map object designed for the QuakeCon 2001 Map Model Competition. It is the skull of a dead dragon.
Made solely for the QuakeCon 2001 Map Model Competition and can only be used for the sole purpose of the QuakeCon 2001 Map Model Competition, atleast until after the competition has ended and consent has been given by the Authors Skizot and Janus.

================================================================ 
Construction 

Poly Count                     : 605
Vert Count                     : 901
Base                           : An idea from Skizot.
Editors used                   : PS6.0, 3D Studio Max R3.1, Npherno's MD3 Compiler, Texporter, Deep Paint 3d, PSP 7.0
Known Bugs                     : None
Model Build  Time              : About 9 hours. (a month on and off)
Skin Build  Time               : 6 hours straight (caffiene and nicotine how I love thee)

================================================================
Copyright / Permissions 
QUAKE III Arena(R) and QUAKE II(R) and QUAKE(R) are registered trademarks of id Software, Inc. This map object is not being distributed for profit reasons, and cannot be altered without the creators' express and written permission. 


*******************************************************************************
27 Cling Ons
*******************************************************************************
Author: 	Daniel "smeg" Vogt
Email:		thevogts@writeme.com 

Construction time:	Somewhere between 1 and 2 weeks.
Construction tools:	Photoshop 5.5
			MAX 3
			Q3ASE (great program)
			Npherno's Tools
			Pop'N'Fresh's exporter
			Notepad (gotta love)

PK3 name:	md3_cling_ons.pk3

-- Plug --

	First things first, I'd like to take this opportunity to mention that I am seeking employment as an artist, and would love for you to drop me a line!  (I am currently based in Australia but am considering relocation). I am dead serious about entering the games industry, and would love any opportunity to do so.

-- Notes --

	FOR BEST RESULTS, place this model above a void, throw in a clip brush and a megahealth / rocket launcher / bfg, and you've got a nice centrepiece.

	Ok, this is a major model with a number of accompanying models.  Firstly, main.md3 is the, uh, main model.  Aura.md3 is an additional (also optional) piece of eyecandy that can be attached if the level designer so desires.  If you want to attach the aura, simply line up the origins in q3radiant.  Email me if you can't work it out :D

	Secondary.md3 is intended as a stepping stone to the larger main.md3.

	The other models are posed skeletons that you may want to scatter around the same room.  There are skeletons lying face down, flat on their backs, hanging from ledges, impaled... the list goes on.

	Finally, if you are having trouble lighting the skeletons, consider having light come from the other direction.  Because a double-sided face is only lit from one side (in quake3), it may be appearing darker than it should.

	For the curious, each skeleton is only 67 polygons.

-- Thanks --

	Thanks to everyone over on #model_design!  Without them, this model would still have existed...  but they made the endless bouts with NPherno's tools much more tolerable.  

Special thanks go to: Shainiel, Cassar (also the remainder of Half-Brick) Ari, Janus, MTE, Sec, R3koil and everyone else who's names I've forgotten.


*******************************************************************************
31 Oak-Tree
*******************************************************************************
Oak-tree Mapmodel (c)GrimReaper
E-mail:  Grimreaper@planetquake.com

Files included in the .pk3 :

Oak.shader
Oakstamm.jpg
Oakstamm2.jpg
Oakblaetter.tga
Oakblaetter2.tga
Oakblaetter3.tga
Oak1.md3 (555 polys)
Oak2.md3 (555 polys)
Oak3.md3 (555 polys)
Oak4.md3 (418 polys)
Oak5.md3 (418 polys)



*******************************************************************************
32 Dissonance
*******************************************************************************
Dissonance - A Quake 3 Arena map model set
Technical Information: Adamantius (Polygons: 581, Skin: 1 512x512, 1 256x256), Vehementi (Polygons: 704, Skin: 1 512x512, 1 256x256), Grimoire Confligere (Polygons: 903, Skin: 1 512x512), Window 1 (Polygons: 278, Skin: 1 512x512), Window 2 (Polygons: 611, Skin: 1 512x512, 3 128x128), Window 3 (Polygons: 196, Skin: 3 256x256) 

Author: Barry �HyPer� Collins
Phone: 1-604-483-3110
E-mail: hyper@prcn.org

Fiction by: Brad Collins
Testing: Nathaniel "Jitspoe" Wulf
Special Thanks: Paul Jaquays

In the year 1804, the statues Vehementi and Adamantius were presented in tribute to the valiance of a warrior-statesman upon the consecration of his imperial ascent. As a gift to Napoleon Bonaparte, these statues stood outside the palace of Versailles for one night before their banishment to the bottom of the Mediterranean. This is the tale of the statues that wear within their robes the heart of conflict; the seed of dissonance, wrought by hands of good intention to ill effect:

Shortly before Napoleon's consecration as Emperor, the call went out throughout his empire to deliver to him a tribute to his glory as a warrior king in the form of artistic expression. Napoleon being a lover of art, and a legendary narcissist always looked forward to seeing the next rendering of his stature, especially now since he occupied the new Imperial throne of France. This idea pleased him greatly, and a competition was announced where all artists seeking to adorn his palace with their tributes would bring their works to him on his birthday in 1804. To the winner, the title of Imperial artist would be given, and he would be granted power to form institutions of secular art education. This opportunity would draw out the very best of artists to pay tribute to him, and in doing so, find the greatest of these to place at the center of his plans for artistic education in France. Always seeking to continuously popularize himself with the people of France, he believed this to be yet another winning notch on the scoreboard for his ambitions.

One prospective contestant, Jules Renault, began work immediately on a pair of bronze statues that he envisioned as depicting Napoleon in the two states of war, one of as the aggressor, the other as the protector.  His passion and desire to earn the position of Imperial artist and to bask in the glow of the Emperor's favor was such that he began spending many sleepless nights drafting designs for the statues. In his fervor, he began to despair at his work, believing it to be inadequate and set about working on many revisions without care for sleep or food. Forever unsatisfied with his work, and the date of Napoleon's birthday looming ever nearer, Jules Renault decided it was time to turn to greater powers than his own to aid him in the creation of his magnum opus. 

He turned to a friend of his who was conducting the scholarly study of the Rosetta stone as recovered on Napoleon's Egyptian campaign, and began searching his books for a hint of the arcane magics apparently in abundance throughout the ancient tombs of that antique land. As fortune (or misfortune) would have it, this scholar had finally received into his possession a book he and his colleagues had translated from the walls and tablets found in the tomb of a feared Egyptian military commander. This book had just been returned to him from the Vatican after a lengthy period of research. With it was a letter declaring it to be an unholy blasphemy that while valuable for historical research was a heretical book of foul magic that was to be burned or locked away out of the reaches of the enemies of God. This news intrigued Jules greatly, and fueled by his desire to create a supernatural wonder for Napoleon to behold, he promptly stole the book during a moonless night in September, and began again construction of his statues. 

The Grimoire Confligere, or the Dark Book of Conflict, was the transcription of all writings adorning the tomb of Ha'sepsut, the great commander of Pharoah Ak'natan's army. The majority of the book described methods of combat and organizations of rank and file soldiers in the army, but a small proportion of it described powerful incantations of the war god Montu. It was likely that these spells as transcribed in the Grimoire were taken from the sacred objects and wall releifs of Ha'sepsut's inner sanctum. After gathering the materials necessary, he believed he had found the edge he was looking for. Unfortunately for Jules, he was unprepared for what price the use of such power would exact. 

He worked for many long months in the thick heat and darkness of his workshop, casting and firing the tainted bronze of the statues as tribute to an ideal he no longer knew clearly. The magics of the book soon tainted his vision, and clouded his mind with dark machinations wholly not part of his being. With the blood of many rams and the dark rituals practiced in many segments over the time of their construction, these statues were imbued with the spirit of their intent: Attack and Defense. Jules quickly abandoned Napoleon as his subject and the statues began to take on the shape of incorporeal wraiths shrouded by tattered robes. The magic of the Grimoire consumed him, drove him forward beyond his physical limit, and when the final chisel blow had been laid on the marble base of the second statue, he collapsed and fell into a nightmare wracked sleep that lasted three days. When he awoke, he titled the attacking figure Vehementi, and the defensive figure Adamantius: names that spoke of their purpose. 

At Napoleon's birthday celebration on the grounds of the palace of Versailles, he received all of the entrants to his competition and displayed their works of art throughout the vast grounds of the palace. On one side of the grounds stood Adamantius, and at the other stood Vehementi, separated by mistake, but still unmistakably part of the same dire set. Napoleon being a great appreciator of art knew that while these tattered and haunting images that stood before him were no tribute to him directly, they were instead meant to portray the forces of war and conflict. The statues emanated the spirit of their intent with such force and such an uncanny depth of feeling that it caused Napoleon to shudder despite himself. At the end of the day, he declared that he loved all of the tributes made to him, and that they would all adorn the his castle, but it would be Jules Renault who would be the Imperial artist of France, a man who could capture the very essence of war in a pair of static figures. Truly these statues were the work of a genius... or a madman. Jules was invited to spend the night at Versailles, and was promised the proclamation of his new posting the next day. 

Napoleon had the two mighty figures placed near the gates, facing each other as they were meant to, and retired to his room after admiring the statues once more. As they were put into position, a great tone of discord fell over the palace and a palpable feeling of heaviness and dread hung over Paris like stifling humidity. That night, the people of Paris were kept awake by the fantastic terrors that haunted their dreams, visions of war and death magnified beyond the range of the human experience prevailed in their minds. Great thunderclouds gathered over Paris, pealing earth-shaking cacophonies through the bones of the French capital. Some were driven to madness by the tortured screams of the collective populace, while others unexplainably ran through the streets openly slaying any who they came upon. Napoleon himself was driven to the very brink of madness through terror of this supernatural occurrence. After gathering his wits, he sought out his guard to hear the horrific events made manifest across Paris. Napoleon immediately and unerringly sensing the source of the trouble ordered that the statues were to be taken away immediately and thrown to the bottom of the Mediterranean where they might sink back to hell. 

When the statues were separated again, the air of Paris released its stifling grip on the hearts of its inhabitants, but did little to ease the suffering of the people quailing and trembling under their bedclothes in the darkness. As dawn approached, Napoleon ordered the immediate execution of Jules Renault on counts of treason, public disturbance, and witchcraft. He was killed by the guillotine just outside the gates of the palace were the huddled masses came to seek salvation from their terror. It would be many weeks before Napoleon reconsidered an appointment for Imperial Artist. 

Thus ended the night of the great dissonance. 

Vehementi: Vehementi stands in an accusatory position, his finger pointed menacingly outward. His other hand clasps his robe tightly together lest he be unraveled in his assault. The name Vehementi derives from the root word Vehement, intensity of emotion. In this case he is meant to personify intense rage. 

Adamantius: Adamantius stands with his hand outstretched as if signaling the halt of oncoming forces. His other hand sits tightened into a fist at his side ready to deliver a blow if the enemy attempts to assail him. The name Adamantius is rooted in the word Adamant, an unyielding hardness. This is representative of his nature as a guardian or protector. 

The Grimoire Confligere: The Dark Book of conflict is a translated transcription of the writings in the tomb of Ha'sepsut, a fearsome general of the ancient Egyptian army. Contained within were the rites of Montu, the Egyptian god of war, which Jules sought to use to benefit his designs. Being completely unaware of the mechanics of such power, he was unprepared for the price it would exact and how much it would affect the works that he produced. 

The Windows: The windows that accompany the dissonance set can be used to aid in the influence of old European architecture in a possible map based on the theme of the statues. 

*******************************************************************************
41 Blood Fountain
*******************************************************************************
Author: 	Michel "The-Shadow-TS" Duhaime
Email:		The-Shadow-TS@Home.com

*******************************************************************************
42 Giant
*******************************************************************************
Title: Giant

by "Goreld"  (Eric Landreneau)

3D model by:  Eric Landreneau
Skin by:      Eric Landreneau

----------------------------------------

Contact Information

Name:  Eric Benjamin Landreneau
Email: eland@tamu.edu

----------------------------------------

*******************************************************************************
43 Televised
*******************************************************************************
Model Names             : tele_big.md3, tele_bigupside.md3, tele_superbig.md3
installation directory  : quake3/baseq3/
Author Model/Roq Anim 	: Martin (Naz) Staubli
Skin Author 		: Richard (Fluffy_gIMp) Jolly
Email Address           : naz_nds@hotmail.com, fluffy_gimp@planetquake.com

Model description       : tele_big is as the name already says a large television (162 units tall). 
tele_bigupside is the same model just upside down with the  uv map adjusted.
				  tele_superbig is the final and biggest version
by changing the shader, other RoQ files can be played on the screen (only movies with a resolution of 256*256). or a portal can be mapped on to it...

Other info              : I planned more elements for this model but I just ran 
  out of time  : /
				  maybe next time :)

Additional Credits to   : id Software


big Thanks to           : RR2DO2 for his helping hand getting this model finished in time :)
				  Fluffy_gIMp for making a skin in such short notice

========================================================================
* Construction *
Poly Count              : 920
Vert Count              : 634
Base                    : not enough sleep
Editor used             : LightWave6.5, 3DS Max 3.1, Photoshop 6.1, q3ase, 
                          NPherno, Pop'n fresh, RoQ creator
Build/Animation time    : 2 nights and a half

* Copyright / Permissions *
please give credit when using this model in a map. feel free to change the shader for a custom RoQ file or portal effect





QUAKE(R) and QUAKE III Arena(R) are registered trademarks of id Software, Inc.
