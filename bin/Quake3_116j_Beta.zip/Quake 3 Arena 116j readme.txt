****************************************************************** 
****************************************************************** 
*****                                                        *****
*****     Quake III Arena (c) 1999-2000 Id Software Inc.     *****
*****                  Point Release v1.16j                  ***** 
*****                                                        *****
****************************************************************** 
****************************************************************** 


Since the release of Quake III Arena in 1999, id's development team has been working to address issues that have risen within the code. These issues involved correction of newly discovered errors, responding to requests for new features, adding features to improve on-line functionality, and ways to allow beneficial and fun game modifications -- while still making it hard for players to cheat.

This point release or "patch" includes the program and data corrections made in previous point releases (so you only need the latest patch). Much of the "new" content in this release deals with added functionality. In particular, we've focused on making it easier to distribute and play game modifications (known as "mods") created by talented fans of the game. These modifications can be as simple as substituting rail guns and rail ammo for all weapons in a map, or a new player model and skin; or as complicated as a "Total Conversion" (or "TC") in which all game rules, graphics, maps and sounds are changed to make a brand new game.  History has shown (with several games) that some of these mods can become more popular with on-line players than the original games alone.

Potential mod authors should take note of them when preparing to distribute their mods.

****************************************************************** 
*                                                                *
*               New Updates to version 1.16ij                    *
*                                                                *
****************************************************************** 

-Zombie/Ghost unpure clients no longer remain connected.
-Recursive File System error corrected when running mods with logfile set to 1
-The Auto-download rate is controlled by 'sv_maxRate', specify this value in bytes per second. The maximum band rate caps out around 25K per second.

****************************************************************** 
*                                                                *
*               New Updates to version 1.16i                     *
*                                                                *
****************************************************************** 

---------------------  
| Security update |
--------------------- 
This update adds an additional layer of CD Key security.

When you type your CD Key in, the letters and numbers will appear as they normally would. If you leave the screen and return at a later time, blank spaces replace all the characters.



****************************************************************** 
*                                                                *
*               Feature and Functionality Changes                *
*                                                                *
****************************************************************** 

-------------------------
| Pure Servers/Cheating | 
-------------------------
There were some flaws in the original implementation of "Pure Servers." The intent was to keep players from cheating (gaining unfair advantage when playing against other players) by modifying or hacking game code or data on the client (player) side. When a server administrator set his server to run pure, it had the unfortunate side effect of booting out players who had personal character skins or new map pk3 files in their directories.  That was not what id intended.

Server administrators, who want to help prevent cheating, need to run a pure server. This point release adds server side authentication of pure clients. Pure servers now will prohibit entry into a game (with a warning message) if a client is USING a modification that the server is not using (or does not possess as in the case of unique character skins). If a server administrator does not run a pure server, then the game is wide open to any number of cheats.

Serves must also be set to PURE if the server administrator wishes to allow auto downloading.

--------------------
| Auto Downloading |
--------------------
Auto-download was a feature that id patched into the Quake 2 code well after the game was released. It was a wonderful feature for the makers of smaller mods, and for players with fast Internet or local network connections. Players gained easy access to the mod-makers' work.  But for players with dial-up modems, or for attempts to download large modifications (like maps or total game conversions), it was horrible. For that reason, we were concerned about the effects that auto-downloading might have on the quality Quake III Arena play. And with that in mind, id chose not to include auto-downloading with the game.

With this point release, Auto download is active. The default setting for both game servers and game players is "ON."

Auto download can be turned on or off (on the client or player side) by a button on the Setup=>Game Options menu. Set it to "ON" if you want to receive files from a server and "OFF" if you don't. The default value is "ON." If you are comfortable entering commands on the game console's command line, type in "/cl_allowdownload 0" to disable it and hit ENTER. "/cl_allowdownload 1" will turn it on again.  

For Auto downloading to work, the server MUST be set to PURE. Non-pure servers will not auto-download game content. 

There is currently no menu command to enable or disable Server side auto download. On the server side, the auto download commands can only be made through the game console. The default value for server side auto download is on. Server administrators may deactivate auto-download with the c_var command "/sv_allowdownload 0" followed by ENTER. "/sv_allowdownload 1" followed by ENTER turns it on again.


How Auto Downloading works:
---------------------------
The server presents a list of referenced PK3 files to the client (player) computer. In turn the client checks to see if those PK3 files are present in its Quake III Arena folder and, if not, it asks the server to send them. The rules for what is transmitted are as follows:

1. A checklist of all the PK3 files in the server's current fs_game directory (a directory at the same "level" as baseq3 in the Quake III Arena folder that contains game variant mods) is sent to the client computer for comparison purposes. This allows mod authors to add an update to a mod, distribute just the PK3 file containing the changes and have only the new one auto-download.

2. The client computer looks to see which PK3s are being "referenced" (actively used) by the server. Only "referenced" PK3 files are then transmitted from baseq3. This prevents a server from dumping several hundred accumulated PK3 files down to clients. Generally, this includes the entire contents of the fs_game directory containing the mod, and any PK3 file (such as maps) in the baseq3 directory that are being used by the server.

3. PK3 files are checksum compared so if a server has a different checksum than what the client has, the client will download the PK3 from the server.

We strongly recommend that mod makers use a standardized method of naming new versions of their mods. This "versioning" should be done using the PK3 naming mechanism we use when releasing new content. To do this, name your PK3 files in an order that will cause the engine to reference the latest one. Essentially this comes down to naming subsequent versions of your PK3 files properly, like pak0, pak1, pak2, pak3, and so on. PK3 file names need to be all lower case. Example: q3Bobsrevenge0. Might be the first release of a game mod. The next version, which fixes the "Bob drops his gun" bug, would be q3Bobsrevenge1, and so on.

PK3 files are the ONLY file type that will be auto-downloaded. Mods or other game assets not contained within PK3 files will NOT download.

---------------
| DLL Loading |
---------------
A "DLL" is a Dynamic Load Library file. It is a file type unique to the MS Windows environment and is not cross platform compatible (meaning that DLL files will not work on Macintosh computers or PCs using operating systems other than Windows). DLL files also present potential security risks to individual computers that are outside id Software's ability to control or adequately protect against. For those reasons, id strongly recommends against loading game DLL files to modify Quake III Arena and even more strongly requests that all game mods be created as cross-platform compatible QVM files and not as DLLs.

DLL's are now loaded from the appropriate game path (based on fs_game). 
Dedicated servers load DLL's without the confirmation dialog. The ability to load game DLL files is turned on by default. Clients can turn OFF the confirmation dialog by with the console command: "/com_blindlyLoadDLLs  1".
 

---------------
| Mod Support |
---------------
Game modifications, or "mods" are now supported by Mod option on the main menu. Clicking on the "Mods" menu entry will present the user with a list of installed game modifications. 

----------------------
| Mod Creation Notes |
----------------------
To be included on the menu, your mod needs to be in a directory under the game installation ( a peer with baseq3 ), and contain at least one PK3 file. Optionally you can include a "description.txt", which if present the first 48 characters will be presented as the mod name. If a "description.txt" is not found, the directory name is used.

------------------
| Server Browser |
------------------
Ping is the time (approximately) in milliseconds needed for a packet of information to travel from the client to the server and then return. Even though the Quake III Arena Internet code works to make the game playable at most ping rates, lower pings are always a good thing to have.

Minimum and Maximum Ping Exclusions
===================================
Server administrators now have the option to exclude players whose pings are too high (connections so poor that the player cannot reasonably play and is just taking up a space in the map), or too low (players whose high-speed connection rates are so good that they may have an advantage over other players connecting at slower speeds). 

These options are turned off by default. 

The console command "/sv_maxPing [non-zero value]" turns the feature on and sets the maximum acceptable ping value number for a connecting client. Example: /sv_maxPing 450 would lock out players with initial ping connections of greater than 450.

The console command "/sv_minPing [non-zero value]" turns the feature on and sets the minimum acceptable ping value number for a connecting client. Example: /sv_minPing 150 would lock out players with initial ping connections of less than 150.

It should go without saying that if both these commands are set, the maxPing has to be greater than the minPing or no one will be able to connect.

Ping Feedback
=============
The server browser has been modified to give more immediate feedback on whether a server will provide a satisfactory game experience for the player. The color of the ping number now indicates the relative quality of the connection, suggesting good vs. bad pings. If the ping number is green, it means a good (< 200) connection. Yellow means marginal (200 to 400) and Red is considered poor (400+). Finally,a blue ping number indicates that the player's ping is either too high or too low based on the server's min or max ping settings.

Mod Feedback
============
The player's browser now shows the mod, if any, being run by the server.


---------------------------
| Fixes/Additions/Changes |
---------------------------
Point Release v1.16i
====================
-fixed CD Key Security Hole

Point Release v1.16h 
==================== 
-fixed splash damage trading armor for health bug
-fixed hang at gamestate/snapshot when server restarts during long map load
-fixed auto-download time remaining bug
-fixed callvote exploit
-fixed no longer take falling damage when wearing the powersuit
-fixed no longer able to do damage with the gauntlet while in chat/console mode 
-fixed curve lod's are more correctly represented in certain cases
-fixed win32 executable will recognize a Linux Q3A cd
-fixed dll's load from fs_game path
-added min/max pings to server settings
-added ping information to server browser
-added mod ui
-added auto-downloading
-added allow downloads to menu
-added cl_paks only sent to pure servers
-added make sure file system restarts if a pk3 was auto-downloaded
-added server browsers shows mod running



****************************************************************** 
*                                                                *
*                        Revision History                        *
*                                                                *
****************************************************************** 

Version 0.41 - Jan.19.2000 
  * Added known issues with A3d 
  * Updated nVidia driver information 

Version 0.4  Jan.7.2000
  * Added new features list and fixed bug list.

Version 0.3  Dec.30.1999
  * Added "Why does the game sometimes crash if we callvote to another level  while playing CTF?" 

Version 0.2 - Dec.29.1999
  * Added "I'm dropped back to the menu when the server changes levels" 
  * Added "I'm getting stuck at Awaiting Snapshot..." 
  * Added "I'm getting stuck at Awaiting Gamestate..." 

Version 0.1 - Dec.29.1999
  * Initial Release 





