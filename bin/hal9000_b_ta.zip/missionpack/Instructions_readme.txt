Team Arena Map Pack 1 Update

This .zip file contains the updated version of Hal9000's Team Arena map, "An Iteration of TA Hell". The original map contained a play bug which is fixed in the the enclosed version. The new map file has a different file name. Additionally, the file contains config scripts that have been updated to use the new map file.

INSTRUCTIONS:
Open the .zip file and select EXTRACT. Make certain that you have the "use folder names" option selected. Extract all files into your main Quake III Arena game folder. The paths will send the files to the correct locations This map is designed for use with Quake III: Team Arena. If you do not own the Team Arena add-on for Quake III, this map will lose functionality in the form of missing textures, items, and game play options.

WARNING! These server scripts will delete any 'q3config.cfg' files you have any your Quake 3 directory. We strongly recommend backing those particular files up in another directory before running the server batch file scripts.
A full readme file is located inside the enclosed .pk3 file for each map.

POST PRODUCTION NOT:

*      The included server batch file scripts assume that the server computer is running with at least 96 megabytes of RAM. If your computer has only 64 megabytes of RAM, you will need to edit the Set RAM line of each script to 56.

*      Japanese Castles TA (japanc_ta.bsp) does not have a spawn spot for free for all or tournament play. If you start the game from the console, set the game type to one of the four team gamestyles first (/g_gametype #). 4 = CTF, 5 = Oneflag, 6 = Overload, 7 = Harvester.

*      Crossed Paths v.TA (dbox2_ta.bsp) does not appear in the Overload game menu. All the entities are in place for it, but the arena file is miswritten. You may start the game from the console or connect to it on-line with no problem.

